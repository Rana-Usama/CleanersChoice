import {Colors} from '../constants/Themes';
import {
  SubscriptionBadgeKey,
  SubscriptionStatus,
} from '../types/admin';

/**
 * Resolving a cleaner's subscription state for the admin views.
 *
 * `Users.subscriptionStatus` is the source of truth, written by the Stripe and
 * Apple webhooks. It is optional by design: users who existed before that field
 * was introduced (and who haven't had a webhook fire since) won't have it, and
 * the backfill script is optional. So every read goes through
 * `resolveSubscriptionStatus`, which falls back to deriving a status from the
 * legacy fields the app has always written.
 *
 * The fallback mirrors `deriveLegacyStatus()` in CleanersChoice-Server
 * (lib/subscriptions.js) so the app and the backfill agree.
 */

interface SubscriptionFields {
  subscriptionStatus?: SubscriptionStatus | string | null;
  subscription?: boolean;
  subscriptionEndDate?: number | null;
  cancelSubscription?: boolean;
  subscriptionId?: string | null;
}

const KNOWN_STATUSES: SubscriptionStatus[] = [
  'active',
  'past_due',
  'canceled',
  'expired',
  'refunded',
  'incomplete',
  'none',
];

/**
 * Returns the canonical status, or null when it genuinely cannot be determined
 * (no `subscriptionStatus` and no legacy fields to derive from).
 */
export const resolveSubscriptionStatus = (
  user?: SubscriptionFields | null,
  now: number = Date.now(),
): SubscriptionStatus | null => {
  if (!user) return null;

  // 1. Source of truth, when the webhooks have written it.
  const stored = user.subscriptionStatus;
  if (
    typeof stored === 'string' &&
    KNOWN_STATUSES.includes(stored as SubscriptionStatus)
  ) {
    return stored as SubscriptionStatus;
  }

  // 2. Legacy fallback. Deliberately conservative — it never reports a paying
  //    cleaner as lapsed.
  const end =
    typeof user.subscriptionEndDate === 'number' ? user.subscriptionEndDate : null;
  const hasEverSubscribed = !!user.subscription || !!user.subscriptionId;

  if (!hasEverSubscribed) return 'none';
  if (end === null) return user.subscription ? 'active' : 'expired';
  if (end <= now) return 'expired';
  return 'active';
};

/**
 * Collapse the seven stored statuses onto the badges the client asked for:
 * Active / Overdue / Expired, plus honest handling for cleaners who never
 * subscribed and for docs we can't resolve at all.
 *
 * `canceled`, `refunded` and `incomplete` all read as "Expired" to the admin —
 * from a monitoring standpoint they're the same thing (no live subscription) —
 * but they stay distinct in Firestore, so separate badges are a one-line change
 * here if the client later wants them.
 */
export const toBadgeKey = (
  status: SubscriptionStatus | null,
): SubscriptionBadgeKey => {
  switch (status) {
    case 'active':
      return 'active';
    case 'past_due':
      return 'overdue';
    case 'expired':
    case 'canceled':
    case 'refunded':
    case 'incomplete':
      return 'expired';
    case 'none':
      return 'none';
    default:
      return 'unknown';
  }
};

export interface BadgeStyle {
  label: string;
  bg: string;
  border: string;
  text: string;
  icon: string;
  iconName: string;
}

/** Palette built from existing theme tokens so nothing new is introduced. */
export const SUBSCRIPTION_BADGES: Record<SubscriptionBadgeKey, BadgeStyle> = {
  active: {
    label: 'Active',
    bg: Colors.greenBg100,
    border: Colors.greenBorder,
    text: Colors.green800,
    icon: Colors.green500,
    iconName: 'check-circle',
  },
  overdue: {
    label: 'Overdue',
    bg: Colors.amberBg50,
    border: Colors.amberBorder,
    text: Colors.amberDarkText,
    icon: Colors.amber500,
    iconName: 'alert-circle-outline',
  },
  expired: {
    label: 'Expired',
    bg: Colors.redBg50,
    border: Colors.redBorder200,
    text: Colors.red500,
    icon: Colors.red500,
    iconName: 'close-circle-outline',
  },
  none: {
    label: 'No Subscription',
    bg: Colors.gray50,
    border: Colors.gray200,
    text: Colors.secondaryText,
    icon: Colors.placeholderColor,
    iconName: 'minus-circle-outline',
  },
  unknown: {
    label: 'Unknown',
    bg: Colors.gray50,
    border: Colors.gray300,
    text: Colors.placeholderColor,
    icon: Colors.placeholderColor,
    iconName: 'help-circle-outline',
  },
};

export const getSubscriptionBadge = (key: SubscriptionBadgeKey): BadgeStyle =>
  SUBSCRIPTION_BADGES[key] ?? SUBSCRIPTION_BADGES.unknown;

/** Convenience: user doc -> badge key in one call. */
export const getBadgeKeyForUser = (
  user?: SubscriptionFields | null,
  now?: number,
): SubscriptionBadgeKey => toBadgeKey(resolveSubscriptionStatus(user, now));

/** Filter chip keys used on the Cleaner Services admin screen. */
export const SUBSCRIPTION_FILTERS: Array<{
  key: 'all' | SubscriptionBadgeKey;
  label: string;
}> = [
  {key: 'all', label: 'All'},
  {key: 'active', label: 'Active'},
  {key: 'overdue', label: 'Overdue'},
  {key: 'expired', label: 'Expired'},
];
