import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Dimensions,
  Modal,
  Platform,
  TouchableWithoutFeedback,
  StatusBar,
  Animated,
} from 'react-native';
import React, {useState, useRef, useEffect, useMemo} from 'react';
import {Colors, Fonts, Icons, IMAGES} from '../../../constants/Themes';
import CachedImage from '../../../components/CachedImage';
import ServiceCoverImage from '../../../components/ServiceCoverImage';
import {getCachedImageUri, prefetchImages} from '../../../utils/imageCache';
import {RFPercentage} from 'react-native-responsive-fontsize';
import LinearGradient from 'react-native-linear-gradient';
import GradientButton from '../../../components/GradientButton';
import {useNavigation} from '@react-navigation/native';
import moment from 'moment';
import {useSelector} from 'react-redux';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Fontisto from 'react-native-vector-icons/Fontisto';
import Feather from 'react-native-vector-icons/Feather';
import ImageView from 'react-native-image-viewing';
import ServicePackage from '../../../components/ServicePackage';

import GuestAuthModal from '../../../components/GuestAuthModal';
import {BlurView} from '@react-native-community/blur';

const {width} = Dimensions.get('window');

const items = [
  {
    id: '11',
    name: 'Window Cleaning',
    icon: 'window-open',
  },
  {
    id: '22',
    name: 'Chimney Cleaning',
    icon: 'fireplace',
  },
  {
    id: '33',
    name: 'Carpet Cleaning',
    icon: 'vacuum',
  },
  {
    id: '44',
    name: 'Residential Cleaning',
    icon: 'home',
  },
  {
    id: '55',
    name: 'Pressure Washing',
    icon: 'water-pump',
  },
  {
    id: '66',
    name: 'Car Washing',
    icon: 'car-wash',
  },
  {
    id: '77',
    name: 'Lawn Care',
    icon: 'leaf',
  },
  {
    id: '88',
    name: 'Others',
    icon: 'dots-horizontal',
  },
];

const ServiceDetails: React.FC = ({route}: any) => {
  const {item} = route.params;
  const [visibleItems, setVisibleItems] = useState(5);
  const navigation = useNavigation<any>();
  const profileData = useSelector((state: any) => state.profile.profileData);
  const [loading, setloading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const scrollY = useRef(new Animated.Value(0)).current;
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [visible, setIsVisible] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [packageModalVisible, setPackageModalVisible] = useState(false);

  console.log('selectedPackage.........', selectedPackage);

  const toggleDescription = () => {
    setIsExpanded(prevState => !prevState);
  };

  const [step, setStep] = useState(0);
  const scrollViewRef = useRef(null);

  const onScroll = (event: any) => {
    const contentOffsetX = event.nativeEvent.contentOffset.x;
    const index = Math.round(contentOffsetX / width);

    if (index !== step) {
      setStep(index);
      setActiveImageIndex(index);
    }
  };

  const handleShowMore = () => {
    setVisibleItems(prev => Math.min(prev + 5, item.type.length));
  };

  const handleShowLess = () => {
    setVisibleItems(5);
  };

  const getServiceWithIcon = (serviceId: any) => {
    return items.find(service => service.id === serviceId);
  };

  const serviceNames = item?.type
    ?.slice(0, visibleItems)
    .map((id: any) => getServiceWithIcon(id));
  const createdAtDate = new Date(item.createdAt._seconds * 1000);
  const formattedDate = moment(createdAtDate).format('DD MMMM, YYYY');
  const relativeDate = moment(createdAtDate).fromNow();
  const userFlow = useSelector((state: any) => state.userFlow.userFlow);

  const galleryImages: string[] = useMemo(
    () =>
      (item?.serviceImages ?? []).filter(
        (url: any) => typeof url === 'string' && url.length > 0,
      ),
    [item?.serviceImages],
  );

  /**
   * Locally cached copies of the gallery, used by the fullscreen viewer.
   *
   * `react-native-image-viewing` mounts every image at once and has no cache
   * of its own, so handing it the remote URLs meant re-downloading the whole
   * gallery the moment a user tapped a photo. Resolving to `file://` URIs up
   * front makes the viewer open instantly and reuses the exact same bytes the
   * inline carousel already fetched.
   */
  const [viewerUris, setViewerUris] = useState<string[]>(galleryImages);

  useEffect(() => {
    if (galleryImages.length === 0) {
      setViewerUris([]);
      return;
    }

    // The visible carousel is what the user is waiting on, so it goes first
    // and the rest of the gallery streams in behind it.
    prefetchImages(galleryImages, {highPriority: true});
    prefetchImages([item?.image], {highPriority: true});

    let cancelled = false;
    Promise.all(
      galleryImages.map(url =>
        getCachedImageUri(url, {highPriority: true}).catch(() => url),
      ),
    ).then(uris => {
      if (!cancelled) {
        setViewerUris(uris);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [galleryImages, item?.image]);

  const imageObjects = useMemo(
    () => viewerUris.map(uri => ({uri})),
    [viewerUris],
  );

  /**
   * How far into the carousel we have mounted real images.
   *
   * Starts at the first two pages so the cover the user actually sees paints
   * without competing with five other decodes, then stays two pages ahead of
   * the swipe. It only ever grows, so scrolling back never triggers a second
   * decode of an image that is already on screen.
   */
  const [mountedThrough, setMountedThrough] = useState(1);

  useEffect(() => {
    const lookahead = step === 0 ? 1 : step + 2;
    setMountedThrough(previous => Math.max(previous, lookahead));
  }, [step]);

  const getTruncatedText = (text: any) => {
    const maxChars = 120;
    if (text.length <= maxChars) return text;
    return text.slice(0, maxChars).trim() + '... ';
  };

  const user = auth().currentUser;
  const userId = user?.uid;
  const generateChatId = () => {
    return `${userId}_${item.id}`;
  };
  const chatId = generateChatId();
  const [existingChatId, setExistingChatId] = useState<string | null>(null);

  const fetchExistingChatId = async (userId1: any, userId2: any) => {
    try {
      const chatsSnapshot = await firestore()
        .collection('Chats')
        .where('participants', 'array-contains', userId1)
        .get();

      for (const doc of chatsSnapshot.docs) {
        const chatData = doc.data();
        const participants = chatData.participants || [];

        if (participants.includes(userId1) && participants.includes(userId2)) {
          return doc.id;
        }
      }
      return null;
    } catch (error) {
      return null;
    }
  };

  useEffect(() => {
    const tryToFindChat = async () => {
      if (user?.uid && item?.jobId) {
        const chatId = await fetchExistingChatId(userId, item.id);
        if (chatId) {
          setExistingChatId(chatId);
        }
      }
    };
    tryToFindChat();
  }, [userId, item?.id]);

  const [token, setFcmToken] = useState<string>('');
  useEffect(() => {
    fetchToken(item.id);
  }, []);

  const fetchToken = async (id: any) => {
    try {
      const userDoc = await firestore().collection('Users').doc(id).get();
      if (userDoc.exists) {
        const userData = userDoc.data();
        setFcmToken(userData?.fcmToken);
      }
    } catch (error) {}
  };

  const cleanDescription = item.description.replace(/\s+/g, ' ').trim();



  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar
        backgroundColor={Colors.gradient1}
        barStyle="light-content"
        translucent
      />

      <ScrollView
        contentContainerStyle={{paddingBottom: RFPercentage(15)}}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{nativeEvent: {contentOffset: {y: scrollY}}}],
          {useNativeDriver: false},
        )}
        scrollEventThrottle={16}>
        {/* Image Gallery with Gradient Overlay */}
        <View style={styles.imageGalleryContainer}>
          <ScrollView
            horizontal
            onScroll={onScroll}
            ref={scrollViewRef}
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            scrollEventThrottle={16}
            style={styles.imageScrollView}>
            {/*
              A service with no photos would otherwise render an empty carousel —
              a blank band above the content. One branded placeholder page keeps
              the header the same height it always is.
            */}
            {galleryImages.length === 0 && (
              <ServiceCoverImage
                uri={null}
                resizeMode="cover"
                style={styles.coverImage}
              />
            )}
            {galleryImages.map((image: string, index: number) => (
              <TouchableOpacity
                key={`${image}-${index}`}
                activeOpacity={0.9}
                onPress={() => {
                  setStep(index);
                  setIsVisible(true);
                }}>
                {/*
                  Pages are mounted lazily. Mounting all six covers at once
                  meant six full-size decodes competing on the same frame, which
                  is why the first photo took so long to appear. Off-screen pages
                  keep an identically sized placeholder so the paging offsets and
                  the dots indicator never shift.
                */}
                {index <= mountedThrough ? (
                  <CachedImage
                    source={{uri: image}}
                    resizeMode="cover"
                    style={styles.coverImage}
                    highPriority
                  />
                ) : (
                  <View style={[styles.coverImage, styles.coverPlaceholder]} />
                )}
                <LinearGradient
                  colors={['transparent', Colors.blackOverlay10, Colors.blackOverlay30]}
                  style={styles.imageGradient}
                />
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation.goBack()}
            style={{
              position: 'absolute',
              top: RFPercentage(2),
              left: RFPercentage(2),
              width: RFPercentage(4.5),
              height: RFPercentage(4.5),
              borderRadius: RFPercentage(100),
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: Colors.blackOverlay30,
            }}>
            <Feather
              name="arrow-left"
              color={Colors.background}
              size={RFPercentage(2.4)}
            />
          </TouchableOpacity>

          {/* Image Counter */}
          {galleryImages.length > 1 && (
            <View style={styles.imageCounter}>
              <View style={styles.counterBadge}>
                <Text style={styles.counterText}>
                  {activeImageIndex + 1} / {galleryImages.length}
                </Text>
              </View>
            </View>
          )}

          {/* Dots Indicator */}
          {galleryImages.length > 1 && (
            <View style={styles.dotsContainer}>
              {galleryImages.map((_: string, index: number) => (
                <TouchableOpacity
                  activeOpacity={0.8}
                  key={index}
                  onPress={() => {
                    setStep(index);
                    setActiveImageIndex(index);
                    scrollViewRef?.current?.scrollTo({
                      x: width * index,
                      animated: true,
                    });
                  }}>
                  {step === index ? (
                    <LinearGradient
                      colors={[Colors.gradient1, Colors.gradient2]}
                      style={styles.activeDot}
                    />
                  ) : (
                    <View style={styles.inactiveDot} />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        {/* Main Content Container */}
        <View style={styles.contentContainer}>
          <View style={styles.serviceHeaderCard}>
            <LinearGradient
              colors={[Colors.gradient1, Colors.gradient2]}
              style={styles.serviceBadge}>
              <Ionicons name="sparkles" size={16} color={Colors.white} />
              <Text style={styles.serviceBadgeText}>Premium Service</Text>
            </LinearGradient>

            <View style={styles.serviceTitleRow}>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => setModalVisible(true)}
                style={styles.profileImageContainer}>
                {/*
                  `item.image` is a snapshot of the cleaner's profile photo and
                  is null when they published the service without one. The
                  fallback sits underneath so this never renders as an empty
                  circle inside the avatar ring.
                */}
                <CachedImage
                  source={{uri: item.image}}
                  fallbackSource={IMAGES.defaultPic}
                  resizeMode="cover"
                  style={styles.profileImage}
                  showSkeleton={false}
                  highPriority
                />
                <View style={styles.verifiedBadge}>
                  <MaterialCommunityIcons
                    name="check-decagram"
                    size={12}
                    color={Colors.white}
                  />
                </View>
              </TouchableOpacity>

              <View style={styles.serviceTitleContainer}>
                <Text style={styles.serviceName}>{item.name}</Text>
                {/* <View style={styles.ratingContainer}>
                  <FontAwesome name="star" size={14} color={Colors.gold} />
                  <Text style={styles.ratingText}>5.0</Text>
                  <Text style={styles.reviewsText}>(24 reviews)</Text>
                </View> */}
              </View>

              <TouchableOpacity
                style={styles.shareButton}
                onPress={() => {
                  if (userFlow === 'Guest') {
                    setShowAuthModal(true);
                    return;
                  }

                  navigation.navigate('Chat', {
                    chatId: existingChatId ? existingChatId : chatId,
                    senderId: profileData.uid,
                    senderName: profileData.name,
                    receiver: item.id,
                    receiverName: item.name,
                    receiverProfile: item.image,
                    senderProfile: profileData.profile,
                    fcmToken: token,
                  });
                }}>
                <Fontisto name="hipchat" size={20} color={Colors.gradient1} />
              </TouchableOpacity>
            </View>

            <View style={styles.metaInfoContainer}>
              <View style={styles.metaItem}>
                <Ionicons
                  name="time-outline"
                  size={16}
                  color={Colors.secondaryText}
                />
                <Text style={styles.metaText}>Posted {relativeDate}</Text>
              </View>
              <View style={styles.metaItem}>
                <Ionicons
                  name="calendar-outline"
                  size={16}
                  color={Colors.secondaryText}
                />
                <Text style={styles.metaText}>{formattedDate}</Text>
              </View>
            </View>
          </View>

          {/* Description Card */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <AntDesign name="setting" size={20} color={Colors.gradient1} />
              <Text style={styles.cardTitle}>Description</Text>
            </View>
            <Text style={styles.descriptionText}>
              {isExpanded
                ? cleanDescription
                : getTruncatedText(cleanDescription)}
              {cleanDescription?.length > 120 && (
                <Text onPress={toggleDescription} style={styles.readMoreText}>
                  {isExpanded ? ' Show less' : ' Read more'}
                </Text>
              )}
            </Text>
          </View>

          {/* Location Card */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Ionicons
                name="location-outline"
                size={20}
                color={Colors.gradient1}
              />
              <Text style={styles.cardTitle}>Location</Text>
            </View>
            <View style={styles.locationContainer}>
              <Ionicons name="pin" size={16} color={Colors.red500} />
              <Text style={styles.locationText}>
                {item?.location?.name || 'Location not specified'}
              </Text>
            </View>
          </View>

          {/* Availability Card */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <MaterialCommunityIcons
                name="calendar-check-outline"
                size={20}
                color={Colors.gradient1}
              />
              <Text style={styles.cardTitle}>Availability</Text>
            </View>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() =>
                navigation.navigate('CheckAvailability', {item: item})
              }
              style={styles.availabilityButton}>
              <LinearGradient
                colors={[Colors.gradient1, Colors.gradient2]}
                style={styles.availabilityGradient}
                start={{x: 0, y: 0}}
                end={{x: 1, y: 0}}>
                <Ionicons
                  name="calendar-clear-outline"
                  size={18}
                  color={Colors.white}
                />
                <Text style={styles.availabilityButtonText}>
                  Check Availability Schedule
                </Text>
                <Feather name="chevron-right" size={18} color={Colors.white} />
              </LinearGradient>
            </TouchableOpacity>
          </View>

          {/* Services Card */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <MaterialCommunityIcons
                name="format-list-bulleted"
                size={20}
                color={Colors.gradient1}
              />
              <Text style={styles.cardTitle}>Services Offered</Text>
            </View>

            <View style={styles.servicesGrid}>
              {serviceNames.map(
                (service: any, index: any) =>
                  service && (
                    <View key={index} style={styles.serviceChip}>
                      <MaterialCommunityIcons
                        name={service.icon}
                        size={16}
                        color={Colors.gradient1}
                      />
                      <Text style={styles.serviceChipText}>
                        {service.name.length > 12
                          ? `${service.name.slice(0, 12)}...`
                          : service.name}
                      </Text>
                    </View>
                  ),
              )}
            </View>

            {item.type.length > 5 && (
              <TouchableOpacity
                activeOpacity={0.8}
                style={styles.showMoreButton}
                onPress={
                  visibleItems < item.type.length
                    ? handleShowMore
                    : handleShowLess
                }>
                <Text style={styles.showMoreText}>
                  {visibleItems < item.type.length
                    ? `View ${item.type.length - visibleItems} more services`
                    : `Show less`}
                </Text>
                <Feather
                  name={
                    visibleItems < item.type.length
                      ? 'chevron-down'
                      : 'chevron-up'
                  }
                  size={16}
                  color={Colors.gradient1}
                />
              </TouchableOpacity>
            )}
          </View>

          {/* Packages Card */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <MaterialCommunityIcons
                name="package-variant"
                size={20}
                color={Colors.gradient1}
              />
              <Text style={styles.cardTitle}>Available Packages</Text>
            </View>

            {Array.isArray(item.packages) && item.packages.length > 0 ? (
              <>
                <View style={styles.packagesHeader}>
                  <View>
                    <Text style={styles.startingFromText}>Starting from</Text>
                    <Text style={styles.startingPrice}>
                      ${item.packages?.[0]?.price || 0}
                    </Text>
                  </View>
                  <View style={styles.bestValueBadge}>
                    <MaterialCommunityIcons
                      name="crown"
                      size={14}
                      color={Colors.white}
                    />
                    <Text style={styles.bestValueText}>Best Value</Text>
                  </View>
                </View>

                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  style={styles.packagesScroll}>
                  {item.packages.map((pkg: any, index: any) => (
                    <ServicePackage
                      key={index}
                      name={`${pkg.name || `Package ${index + 1}`}`}
                      price={pkg.price}
                      detail={pkg.details}
                      onPress={() => {
                        setSelectedPackage(pkg);
                        setPackageModalVisible(true);
                      }}
                      // isSelected
                      // isFeatured
                    />
                  ))}
                </ScrollView>
              </>
            ) : (
              <Text style={styles.startingFromText}>
                This cleaner hasn't listed any packages yet. Request a custom
                offer to get pricing.
              </Text>
            )}
          </View>

          {/* Service Provider Info */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <MaterialCommunityIcons
                name="account-tie"
                size={20}
                color={Colors.gradient1}
              />
              <Text style={styles.cardTitle}>Service Provider</Text>
            </View>

            <View style={styles.providerInfo}>
              <CachedImage
                source={{uri: item.image}}
                fallbackSource={IMAGES.defaultPic}
                resizeMode="cover"
                style={styles.providerImage}
                showSkeleton={false}
              />
              <View style={styles.providerDetails}>
                <Text style={styles.providerName}>{item.name}</Text>
                <View style={styles.providerStats}>
                  <View style={styles.statItem}>
                    <MaterialCommunityIcons
                      name="check-decagram"
                      size={14}
                      color={Colors.success}
                    />
                    <Text style={styles.statText}>Verified</Text>
                  </View>
                  {/* <View style={styles.statItem}>
                    <MaterialCommunityIcons
                      name="star"
                      size={14}
                      color={Colors.gold}
                    />
                    <Text style={styles.statText}>5.0 (24)</Text>
                  </View>
                  <View style={styles.statItem}>
                    <MaterialCommunityIcons
                      name="briefcase-check"
                      size={14}
                      color={Colors.gradient1}
                    />
                    <Text style={styles.statText}>50+ jobs</Text>
                  </View> */}
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Fixed Bottom Action Bar */}
      <View style={styles.bottomActionBar}>
        <View style={styles.priceContainer}>
          {Array.isArray(item.packages) && item.packages.length > 0 ? (
            <>
              <Text style={styles.startingFrom}>Starting from</Text>
              <Text style={styles.bottomPrice}>
                ${item.packages?.[0]?.price || 0}
              </Text>
            </>
          ) : (
            <Text style={styles.startingFrom}>Custom pricing</Text>
          )}
        </View>

        <GradientButton
          title="Get Custom Offer"
          style={styles.actionButton}
          textStyle={styles.actionButtonText}
          onPress={() => {
            if (userFlow === 'Guest') {
              setShowAuthModal(true);
              return;
            }
            setloading(true);
            setTimeout(() => {
              setloading(false);
              navigation.navigate('Chat', {
                chatId: existingChatId ? existingChatId : chatId,
                senderId: profileData.uid,
                senderName: profileData.name,
                receiver: item.id,
                receiverName: item.name,
                receiverProfile: item.image,
                senderProfile: profileData.profile,
                fcmToken: token,
              });
            }, 1000);
          }}
          loading={loading}
        />
      </View>

      {/* Full Screen Image Modal */}
      {modalVisible && (
        <Modal
          visible={modalVisible}
          transparent
          onRequestClose={() => setModalVisible(false)}
          animationType="fade">
          <View style={styles.fullScreenModal}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => setModalVisible(false)}
              style={styles.closeModalButton}>
              <AntDesign name="close" size={24} color={Colors.white} />
            </TouchableOpacity>
            <CachedImage
              source={{uri: item.image}}
              fallbackSource={IMAGES.defaultPic}
              resizeMode="contain"
              style={styles.fullScreenImage}
              highPriority
            />
          </View>
        </Modal>
      )}

      {/* Authentication Required Modal */}
      <GuestAuthModal
        visible={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onContinue={() => {
          setShowAuthModal(false);
          navigation.navigate('UserSelection');
        }}
      />

      <ImageView
        images={imageObjects}
        imageIndex={step}
        visible={visible}
        onRequestClose={() => setIsVisible(false)}
        backgroundColor={Colors.blackOverlay90}
        presentationStyle="fullScreen"
      />

      {packageModalVisible && selectedPackage && (
        <Modal
          visible={packageModalVisible}
          transparent
          animationType="none"
          onRequestClose={() => setPackageModalVisible(false)}>
          <View style={styles.packageModalContainer}>
            <BlurView style={styles.blurView} blurType="dark" blurAmount={10} />
            <View style={styles.packageModalContent}>
              {/* Modal Header */}
              <LinearGradient
                colors={[Colors.gradient1, Colors.gradient2]}
                style={styles.packageModalHeader}>
                <Text style={styles.packageModalTitle}>{item?.name}</Text>
                <TouchableOpacity
                  onPress={() => setPackageModalVisible(false)}
                  style={styles.packageModalClose}>
                  <AntDesign name="close" size={24} color={Colors.white} />
                </TouchableOpacity>
              </LinearGradient>

              {/* Modal Body */}
              <ScrollView style={styles.packageModalBody}>
                <View style={styles.packagePriceSection}>
                  <Text style={styles.packageModalPriceLabel}>Price</Text>
                  <View style={styles.packagePriceRow}>
                    <Text style={styles.packageModalCurrency}>$</Text>
                    <Text style={styles.packageModalPrice}>
                      {selectedPackage?.price}
                    </Text>
                    <Text style={styles.packageModalPriceUnit}>/service</Text>
                  </View>
                </View>

                <View style={styles.packageDetailSection}>
                  <View style={styles.sectionHeader}>
                    <MaterialCommunityIcons
                      name="text-box-outline"
                      size={20}
                      color={Colors.gradient1}
                    />
                    <Text style={styles.sectionTitle}>What's Included</Text>
                  </View>
                  <Text style={styles.packageDetailText}>
                    {selectedPackage?.details}
                  </Text>
                </View>

                {/* Add additional package details if available */}
                {selectedPackage?.services && (
                  <View style={styles.packageServicesSection}>
                    <View style={styles.sectionHeader}>
                      <MaterialCommunityIcons
                        name="check-circle-outline"
                        size={20}
                        color={Colors.gradient1}
                      />
                      <Text style={styles.sectionTitle}>Services Included</Text>
                    </View>
                    {selectedPackage?.services.map((service, index) => (
                      <View key={index} style={styles.serviceItem}>
                        <MaterialCommunityIcons
                          name="check-circle"
                          size={16}
                          color={Colors.gradient1}
                        />
                        <Text style={styles.serviceText}>{service}</Text>
                      </View>
                    ))}
                  </View>
                )}
              </ScrollView>

              {/* Modal Footer */}
              <View style={styles.packageModalFooter}>
                <GradientButton
                  title="Get Package Offer"
                  style={styles.selectPackageButton}
                  textStyle={{fontSize: RFPercentage(1.7)}}
                  onPress={() => {
                    if (userFlow === 'Guest') {
                      setShowAuthModal(true);
                      return;
                    }

                    navigation.navigate('Chat', {
                      chatId: existingChatId ? existingChatId : chatId,
                      senderId: profileData.uid,
                      senderName: profileData.name,
                      receiver: item.id,
                      receiverName: item.name,
                      receiverProfile: item.image,
                      senderProfile: profileData.profile,
                      fcmToken: token,
                    });

                    setPackageModalVisible(false);
                  }}
                />
              </View>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
};

export default ServiceDetails;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  gradientHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    paddingTop: Platform.OS === 'ios' ? 40 : 0,
  },
  headerText: {
    fontSize: RFPercentage(2.1),
    fontFamily: Fonts.semiBold,
    color: Colors.white,
  },
  imageGalleryContainer: {
    height: RFPercentage(35),
    marginTop: Platform.OS === 'ios' ? 0 : 20,
  },
  imageScrollView: {
    width: width,
    height: RFPercentage(35),
  },
  coverImage: {
    width: width,
    height: RFPercentage(35),
  },
  // Keeps an un-mounted carousel page the exact size of a real cover so
  // `pagingEnabled` offsets and the dots indicator stay in sync.
  coverPlaceholder: {
    backgroundColor: Colors.skeletonLight,
  },
  imageGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: RFPercentage(15),
  },
  imageCounter: {
    position: 'absolute',
    top: RFPercentage(2),
    right: RFPercentage(2),
  },
  counterBadge: {
    backgroundColor: Colors.blackOverlay60,
    paddingHorizontal: RFPercentage(1),
    paddingVertical: RFPercentage(0.5),
    borderRadius: 12,
  },
  counterText: {
    color: Colors.white,
    fontSize: RFPercentage(1.4),
    fontFamily: Fonts.fontMedium,
  },
  dotsContainer: {
    position: 'absolute',
    bottom: RFPercentage(2),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  activeDot: {
    width: RFPercentage(1.5),
    height: RFPercentage(1.5),
    borderRadius: RFPercentage(0.75),
    marginHorizontal: RFPercentage(0.3),
  },
  inactiveDot: {
    width: RFPercentage(1),
    height: RFPercentage(1),
    borderRadius: RFPercentage(0.5),
    marginHorizontal: RFPercentage(0.3),
    backgroundColor: Colors.whiteOverlay50,
  },
  contentContainer: {
    paddingHorizontal: RFPercentage(2),
    paddingTop: RFPercentage(2),
    paddingBottom: RFPercentage(15),
  },
  serviceHeaderCard: {
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: RFPercentage(2),
    marginBottom: RFPercentage(2),
    shadowColor: Colors.black,
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.1,
    shadowRadius: 12,
    // elevation: 5,
     borderWidth: 1,
    borderColor: Colors.lightGrayBg,
    borderBottomWidth: 2,
  },
  serviceBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: RFPercentage(1.2),
    paddingVertical: RFPercentage(0.5),
    borderRadius: 20,
    marginBottom: RFPercentage(1),
    gap: RFPercentage(0.5),
  },
  serviceBadgeText: {
    color: Colors.white,
    fontSize: RFPercentage(1.4),
    fontFamily: Fonts.fontMedium,
  },
  serviceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: RFPercentage(1.5),
  },
  profileImageContainer: {
    position: 'relative',
    marginRight: RFPercentage(1.5),
  },
  profileImage: {
    width: RFPercentage(6),
    height: RFPercentage(6),
    borderRadius: RFPercentage(3),
    borderWidth: 2,
    borderColor: Colors.gradient1,
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: Colors.gradient1,
    borderRadius: 10,
    width: RFPercentage(2.5),
    height: RFPercentage(2.5),
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  serviceTitleContainer: {
    flex: 1,
  },
  serviceName: {
    fontSize: RFPercentage(2),
    fontFamily: Fonts.semiBold,
    color: Colors.primaryText,
    marginBottom: RFPercentage(0.3),
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: RFPercentage(0.3),
  },
  ratingText: {
    fontSize: RFPercentage(1.6),
    fontFamily: Fonts.fontMedium,
    color: Colors.primaryText,
    marginLeft: RFPercentage(0.3),
  },
  reviewsText: {
    fontSize: RFPercentage(1.4),
    fontFamily: Fonts.fontRegular,
    color: Colors.secondaryText,
    marginLeft: RFPercentage(0.5),
  },
  shareButton: {
    width: RFPercentage(4.5),
    height: RFPercentage(4.5),
    borderRadius: RFPercentage(2.25),
    backgroundColor: Colors.lightGrayBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  metaInfoContainer: {
    flexDirection: 'row',
    gap: RFPercentage(2),
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: RFPercentage(0.5),
  },
  metaText: {
    fontSize: RFPercentage(1.4),
    fontFamily: Fonts.fontRegular,
    color: Colors.secondaryText,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: RFPercentage(2),
    marginBottom: RFPercentage(2),
    shadowColor: Colors.black,
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.05,
    shadowRadius: 8,
    // elevation: 3,
     borderWidth: 1,
    borderColor: Colors.lightGrayBg,
    borderBottomWidth: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: RFPercentage(1.5),
    gap: RFPercentage(1),
  },
  cardTitle: {
    fontSize: RFPercentage(1.9),
    fontFamily: Fonts.fontMedium,
    color: Colors.primaryText,
  },
  descriptionText: {
    fontSize: RFPercentage(1.7),
    fontFamily: Fonts.fontRegular,
    color: Colors.secondaryText,
    lineHeight: RFPercentage(2.2),
  },
  readMoreText: {
    color: Colors.gradient1,
    fontSize: RFPercentage(1.7),
    fontFamily: Fonts.fontMedium,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: RFPercentage(0.8),
    backgroundColor: Colors.inputBg,
    padding: RFPercentage(1.2),
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
  },
  locationText: {
    fontSize: RFPercentage(1.6),
    fontFamily: Fonts.fontRegular,
    color: Colors.primaryText,
    flex: 1,
  },
  availabilityButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  availabilityGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: RFPercentage(1.5),
    gap: RFPercentage(1),
  },
  availabilityButtonText: {
    color: Colors.white,
    fontSize: RFPercentage(1.6),
    fontFamily: Fonts.fontMedium,
  },
  servicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: RFPercentage(1),
  },
  serviceChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.inputBg,
    paddingHorizontal: RFPercentage(1.2),
    paddingVertical: RFPercentage(0.8),
    borderRadius: 20,
    gap: RFPercentage(0.5),
    borderWidth: 1,
    borderColor: Colors.inputBorder,
  },
  serviceChipText: {
    fontSize: RFPercentage(1.5),
    fontFamily: Fonts.fontMedium,
    color: Colors.primaryText,
  },
  showMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: RFPercentage(1.5),
    gap: RFPercentage(0.5),
  },
  showMoreText: {
    color: Colors.gradient1,
    fontSize: RFPercentage(1.5),
    fontFamily: Fonts.fontMedium,
  },
  packagesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: RFPercentage(1.5),
  },
  startingFromText: {
    fontSize: RFPercentage(1.5),
    fontFamily: Fonts.fontRegular,
    color: Colors.secondaryText,
  },
  startingPrice: {
    fontSize: RFPercentage(2.5),
    fontFamily: Fonts.semiBold,
    color: Colors.gradient1,
  },
  bestValueBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.amber500,
    paddingHorizontal: RFPercentage(1),
    paddingVertical: RFPercentage(0.5),
    borderRadius: 12,
    gap: RFPercentage(0.3),
  },
  bestValueText: {
    color: Colors.white,
    fontSize: RFPercentage(1.3),
    fontFamily: Fonts.fontMedium,
  },
  packagesScroll: {
    marginHorizontal: -RFPercentage(2),
    paddingHorizontal: RFPercentage(2),
  },
  providerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: RFPercentage(1.5),
  },
  providerImage: {
    width: RFPercentage(5),
    height: RFPercentage(5),
    borderRadius: RFPercentage(2.5),
  },
  providerDetails: {
    flex: 1,
  },
  providerName: {
    fontSize: RFPercentage(1.7),
    fontFamily: Fonts.fontMedium,
    color: Colors.primaryText,
    marginBottom: RFPercentage(0.5),
  },
  providerStats: {
    flexDirection: 'row',
    gap: RFPercentage(1.5),
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: RFPercentage(0.3),
  },
  statText: {
    fontSize: RFPercentage(1.4),
    fontFamily: Fonts.fontRegular,
    color: Colors.secondaryText,
  },
  bottomActionBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: Colors.white,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: RFPercentage(2),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: Colors.black,
    shadowOffset: {width: 0, height: -4},
    shadowOpacity: 0.1,
    shadowRadius: 8,
    // elevation: 10,
    paddingBottom: Platform.OS === 'ios' ? RFPercentage(4) : RFPercentage(2),
    borderTopWidth:1,
    borderTopColor: Colors.lightGray200

  },
  priceContainer: {
    flex: 1,
  },
  startingFrom: {
    fontSize: RFPercentage(1.5),
    fontFamily: Fonts.fontRegular,
    color: Colors.secondaryText,
  },
  bottomPrice: {
    fontSize: RFPercentage(2.3),
    fontFamily: Fonts.semiBold,
    color: Colors.gradient1,
  },
  actionButton: {
    flex: 2,
    marginLeft: RFPercentage(1),
  },
  actionButtonText: {
    fontSize: RFPercentage(1.7),
    fontFamily: Fonts.fontMedium,
  },
  fullScreenModal: {
    flex: 1,
    backgroundColor: Colors.blackOverlay90,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeModalButton: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? RFPercentage(6) : RFPercentage(4),
    right: RFPercentage(2),
    zIndex: 2,
    width: RFPercentage(4),
    height: RFPercentage(4),
    borderRadius: RFPercentage(2),
    backgroundColor: Colors.whiteOverlay20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fullScreenImage: {
    width: '90%',
    height: '90%',
  },
  blurView: {
    ...StyleSheet.absoluteFillObject,
  },
  packageModalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  packageModalContent: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '80%',
  },
  packageModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: RFPercentage(2),
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  packageModalTitle: {
    color: Colors.white,
    fontSize: RFPercentage(1.9),
    fontFamily: Fonts.semiBold,
  },
  packageModalClose: {
    padding: RFPercentage(0.5),
  },
  packageModalBody: {
    padding: RFPercentage(2),
  },
  packagePriceSection: {
    alignItems: 'center',
    marginBottom: RFPercentage(2),
  },
  packageModalPriceLabel: {
    color: Colors.secondaryText,
    fontSize: RFPercentage(1.5),
    fontFamily: Fonts.fontRegular,
    marginBottom: RFPercentage(0.5),
  },
  packagePriceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  packageModalCurrency: {
    color: Colors.gradient1,
    fontSize: RFPercentage(2.1),
    fontFamily: Fonts.fontMedium,
  },
  packageModalPrice: {
    color: Colors.gradient1,
    fontSize: RFPercentage(3.6),
    fontFamily: Fonts.fontBold,
    marginHorizontal: RFPercentage(0.5),
  },
  packageModalPriceUnit: {
    color: Colors.secondaryText,
    fontSize: RFPercentage(1.6),
    fontFamily: Fonts.fontRegular,
  },
  packageDetailSection: {
    marginBottom: RFPercentage(2),
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: RFPercentage(1),
    gap: RFPercentage(0.8),
  },
  sectionTitle: {
    color: Colors.primaryText,
    fontSize: RFPercentage(1.7),
    fontFamily: Fonts.fontMedium,
  },
  packageDetailText: {
    color: Colors.secondaryText,
    fontSize: RFPercentage(1.6),
    fontFamily: Fonts.fontRegular,
    lineHeight: RFPercentage(2.2),
  },
  packageServicesSection: {
    marginBottom: RFPercentage(2),
  },
  serviceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: RFPercentage(0.8),
    gap: RFPercentage(0.8),
  },
  serviceText: {
    color: Colors.primaryText,
    fontSize: RFPercentage(1.6),
    fontFamily: Fonts.fontRegular,
    flex: 1,
  },
  packageModalFooter: {
    padding: RFPercentage(2),
    borderTopWidth: 1,
    borderTopColor: Colors.gray200,
  },
  selectPackageButton: {
    marginBottom: RFPercentage(1),
    alignSelf: 'center',
  },
  customizeButton: {
    padding: RFPercentage(1.5),
    alignItems: 'center',
  },
  customizeText: {
    color: Colors.gradient1,
    fontSize: RFPercentage(1.6),
    fontFamily: Fonts.fontMedium,
  },
});
